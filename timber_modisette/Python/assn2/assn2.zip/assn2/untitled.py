
str= "it's thanksgiving day. It's my birthday, too."
print str

x = str[18:21]
print x

y = str[:18]+"month "+str[23:]


