x = [2,54,-2,7,12,98]

print min(x)

print max(x)