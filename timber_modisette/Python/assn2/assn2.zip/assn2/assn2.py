str = "it's thanksgiving day. It's my birthday, too."

print str.find("day")

print(str.replace("day", "month", 1))