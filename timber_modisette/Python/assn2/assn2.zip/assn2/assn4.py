x = ["hello",2,54,-2,7,12,98,"world"]

this = x[0]

that = x[len(x) - 1]

newArr = []

newArr.append(this +" "+ that)

print newArr
