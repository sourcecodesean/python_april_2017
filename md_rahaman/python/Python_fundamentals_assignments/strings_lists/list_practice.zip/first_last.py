

x=["hello",2,54,-2,7,12,98,"world"]
y=[]
y.append(x[0])
y.append(x[len(x)-1])

print(y)